-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 192.168.4.211    Database: morozov
-- ------------------------------------------------------
-- Server version	5.7.22-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student_morozov`
--

DROP TABLE IF EXISTS `student_morozov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_morozov` (
  `N_stud` int(11) NOT NULL AUTO_INCREMENT,
  `FIO` varchar(40) NOT NULL,
  `D_R` date NOT NULL,
  `Gruppa` varchar(8) NOT NULL,
  `Stipendiya` float DEFAULT NULL,
  `Kod_spec` int(11) NOT NULL,
  `Stip_New` float DEFAULT NULL,
  `Premiya` float DEFAULT NULL,
  `YYY` int(11) DEFAULT NULL,
  `MMM` int(11) DEFAULT NULL,
  `DDD` int(11) DEFAULT NULL,
  PRIMARY KEY (`N_stud`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_morozov`
--

LOCK TABLES `student_morozov` WRITE;
/*!40000 ALTER TABLE `student_morozov` DISABLE KEYS */;
INSERT INTO `student_morozov` VALUES (1,'Сидоров','1992-07-23','4п1',18520,3322,NULL,500,NULL,NULL,NULL),(2,'Петров','1993-11-07','2ЗАО1',NULL,4466,900,500,NULL,NULL,NULL),(3,'Григорьев','1992-04-19','4п2',920,8811,NULL,500,NULL,NULL,NULL),(4,'Данилова','1992-06-11','4п2',1200,8811,NULL,500,NULL,NULL,NULL),(7,'Коробкова','1992-11-20','4п2',880,8811,NULL,500,NULL,NULL,NULL),(8,'Смирнов','1991-07-16','4п2',920,8811,NULL,500,NULL,NULL,NULL),(9,'Подгорнова','1991-09-25','4п3',1200,4466,NULL,500,NULL,NULL,NULL),(10,'Лебедев','1991-07-26','4п3',2420,4466,NULL,500,NULL,NULL,NULL),(11,'Карнашев','1992-03-02','4п1',7400,3322,2200,500,NULL,NULL,NULL),(12,'Обозова','1991-08-19','4п3',880,4466,1760,500,NULL,NULL,NULL),(15,'Кочуров','2002-05-16','2ЗАО1',1000,9933,NULL,600,NULL,NULL,NULL),(16,'Воронин','2002-07-12','2ЗАО1',1000,9933,NULL,600,NULL,NULL,NULL);
/*!40000 ALTER TABLE `student_morozov` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`student`@`%`*/ /*!50003 trigger TR5 before insert on student_morozov
for each row
insert into student_morozov values (new.YYY = year(new.D_R), new.MMM = month(new.D_R), new.DDD = day(new.D_R)) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`student`@`%`*/ /*!50003 trigger TR7 before update on student_morozov
for each row
set new.Stipendiya =
case
when new.Gruppa = "4п1" 
then new.Stipendiya+1000
else new.Stipendiya
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-18 15:17:18
